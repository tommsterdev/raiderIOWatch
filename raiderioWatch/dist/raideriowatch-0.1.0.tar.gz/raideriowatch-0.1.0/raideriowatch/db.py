"""
Dynamo DB CRUD operations
"""

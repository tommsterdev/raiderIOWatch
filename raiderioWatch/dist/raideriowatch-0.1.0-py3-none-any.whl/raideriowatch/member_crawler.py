import json
import logging
import os
import asyncio
import httpx
from typing import List, Tuple, Dict
from dotenv import load_dotenv


from member import Member
from guild_crawler import get_guild
from utils import write_members, parse_data
from requests import httpx_get, JSONObject 
from time import perf_counter


logger = logging.Logger(__name__)
load_dotenv()

FIELDS = os.getenv("FIELDS")
API_URL = os.getenv("API_URL")
INPUT_FILE = os.getenv("INPUT_FILE")
OUTFILE = os.getenv("OUTFILE")


print("Loading Function...")


async def parse_response(response: JSONObject) -> Tuple[float, float]:
    """
    Helper function to parse score and ilvl from http response json
    """
    score = 0.0
    ilvl = 0.0
    if response.get("mythic_plus_scores_by_season", None):
        score = response["mythic_plus_scores_by_season"][0]["scores"]["all"]
    if response.get("gear", None):
        ilvl = response["gear"]["item_level_equipped"]
    return score, ilvl


async def request_member(client: httpx.Client, params: Dict[str, str]) -> JSONObject:
    """
    Make http request

    param: url
    return JSONObject
    """
    response: JSONObject = await httpx_get(client=client, params=params)
    if response.get("statusCode", 200) != 200:
        print(response["statusCode"])

    # parsed_response = await parse_response(response)

    return response


async def crawl_member(member: Member, client: httpx.Client) -> Member:
    """
    helper function to construct api endpoint url and parse response
    """
    # construct query url
    params = {
        "region": member.region,
        "realm": member.realm,
        "name": member.name,
        "fields": FIELDS,
    }
    response: JSONObject = await request_member(client=client, params=params)

    member.score, member.ilvl = await parse_response(response)

    return member


async def main() -> None:

    start = perf_counter()

    guild_data: List[Member] = await get_guild()

    # filter inactive members:
    active_members = [member for member in guild_data if member.rank <= 4]

    elapsed = perf_counter() - start
    print(f"get guild execution time: {elapsed:.2f} seconds")

    print(f"getting member data...")
    async with httpx.AsyncClient() as client:
        crawled_members: List[Member] = await asyncio.gather(
            *[crawl_member(member, client) for member in guild_data]
        )

    elapsed = perf_counter() - start
    print(f"crawl_members execution time: {elapsed:.2f} seconds")

    output_file = "pydantic_data_with_scores.json"
    members_json = [member.model_dump() for member in crawled_members]
    write_members(members=members_json, output_file=output_file)

    elapsed = perf_counter() - start
    print(f"dump objects and write to file execution time: {elapsed:.2f} seconds")


if __name__ == "__main__":
    asyncio.run(main())
